
import os
import random
import asyncio
import time
from telethon import TelegramClient, errors
from threading import Thread

SETTINGS_FILE = 'tg_settings.txt'
PHOTOS_DIR = 'photos'
SUPPORTED_PHOTO_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp', '.gif']

def print_header():
    print("\033[1;34m")
    print("      __      _________ ____    _____ _____          _____  ")
    print("     /\\ \\    / /__   __/ __ \\  |  __ \\_   _|   /\\   |  __ \\ ")
    print("    /  \\ \\  / /   | | | |  | | | |__) || |    /  \\  | |__) |")
    print("   / /\\ \\ \\/ /    | | | |  | | |  ___/ | |   / /\\ \\ |  _  / ")
    print("  / ____ \\  /     | | | |__| | | |    _| |_ / ____ \\| | \\ \\ ")
    print(" /_/    \\_\\/      |_|  \\____/  |_|   |_____/_/    \\_\\_|  \\_\\")
    print("═" * 64)
    print("    🚀 АВТОМАТИЧЕСКАЯ РАССЫЛКА В TELEGRAM by AVGUSTINOVICH")
    print("═" * 64)
    print("\033[1;33mТехническая поддержка скрипта: t.me/avgustinovich_ex\033[0m\n")

def print_success(message):
    print(f"\033[1;32m✅ {message}\033[0m")

def print_error(message):
    print(f"\033[1;31m❌ {message}\033[0m")

def print_wait(message):
    print(f"\033[1;33m⏳ {message}\033[0m")

def print_action(message):
    print(f"\033[1;36m📤 {message}\033[0m")

def print_info(message):
    print(f"\033[1;34mℹ️ {message}\033[0m")

def ensure_photos_folder():
    if not os.path.exists(PHOTOS_DIR):
        os.makedirs(PHOTOS_DIR)
        print_info(f"Создана папка для фото: {PHOTOS_DIR}")
        print_info("Положите в эту папку 1 фото (jpg/png/webp/gif), если хотите рассылать сообщения с фото.")

def get_first_photo():
    if not os.path.exists(PHOTOS_DIR):
        return None
    for fname in os.listdir(PHOTOS_DIR):
        path = os.path.join(PHOTOS_DIR, fname)
        if os.path.isfile(path):
            ext = os.path.splitext(fname)[1].lower()
            if ext in SUPPORTED_PHOTO_EXTENSIONS:
                return path
    return None

def save_settings(settings):
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        f.write("# ========= РАЗДЕЛ 1: ДАННЫЕ ДЛЯ АВТОРИЗАЦИИ =========\n")
        f.write("# api_id: получите на https://my.telegram.org\n")
        f.write(f"api_id: {settings['api_id']}\n")
        f.write("# api_hash: получите на https://my.telegram.org\n")
        f.write(f"api_hash: {settings['api_hash']}\n")
        f.write("# phone_number: ваш номер (например, +79991234567)\n")
        f.write(f"phone_number: {settings['phone_number']}\n\n")
        f.write("# ========= РАЗДЕЛ 2: НАСТРОЙКИ РАССЫЛКИ =========\n")
        f.write("# chat_links: ссылки на чаты через запятую (пример: https://t.me/chat1,https://t.me/chat2)\n")
        f.write("chat_links: https://t.me/proverka_mls,https://t.me/proverka_mls1\n")
        f.write("# message_text: текст сообщения для рассылки\n")
        f.write("message_text: Купить автоматическую рассылку телеграм можно у @avgustinovich_ex\n")
        f.write("# interval_seconds: интервал между рассылками (в секундах, например 1800 = 30 минут, можно любое число)\n")
        f.write("interval_seconds: 1800\n")

def load_settings():
    if not os.path.exists(SETTINGS_FILE):
        return None
    settings = {}
    with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and ":" in line:
                key, value = line.split(":", 1)
                settings[key.strip()] = value.strip()
    required = ['api_id', 'api_hash', 'phone_number', 'chat_links', 'message_text', 'interval_seconds']
    if all(k in settings for k in required):
        return settings
    else:
        return None

def get_settings():
    settings = load_settings()
    if settings:
        print_success("Настройки успешно загружены из файла!")
        return settings

    # print_header()  # <-- Убрали повторный вызов заголовка!
    print_info("Пожалуйста, введите необходимые данные для запуска рассылки:")
    settings = {}
    settings['api_id'] = input("🔹 Введите api_id (выдается на https://my.telegram.org): ")
    settings['api_hash'] = input("🔹 Введите api_hash (выдается на https://my.telegram.org): ")
    settings['phone_number'] = input("🔹 Введите ваш номер телефона (+7...): ")
    print_info("Ссылки на чаты вводите через запятую (например: https://t.me/proverka_mls,https://t.me/proverka_mls1)")
    settings['chat_links'] = input("🔹 Введите ссылки на чаты: ")
    settings['message_text'] = "Купить автоматическую рассылку телеграм можно у @avgustinovich_ex"
    print_info("Интервал между рассылками в секундах (по умолчанию 1800 = 30 минут, можно любое число)")
    interval = input("🔹 Введите интервал между рассылками (сек): ").strip()
    settings['interval_seconds'] = interval if interval.isdigit() else '1800'
    save_settings(settings)
    print_success(f"Настройки сохранены в {SETTINGS_FILE} 🎉")
    return settings

async def send_messages(client, chat_links, message_text, photo_path=None):
    for chat in chat_links:
        try:
            print_action(f"Отправка сообщения в {chat} ...")
            if photo_path:
                await client.send_file(chat, photo_path, caption=message_text)
            else:
                await client.send_message(chat, message_text)
            print_success(f"Успешно отправлено в {chat}")
        except errors.ChatWriteForbiddenError:
            print_error(f"Нет прав писать в {chat} — возможно, вы не участник/подписчик. 🚫")
            print_info(f"Подключитесь к чату или каналу: {chat}, затем запустите скрипт снова.")
        except errors.UserPrivacyRestrictedError:
            print_error(f"Вы не можете писать в {chat} из-за настроек приватности.")
        except errors.UserNotParticipantError:
            print_error(f"Вы не участник чата/канала {chat}. Добавьте аккаунт в чат/канал!")
        except Exception as e:
            if "Cannot find any entity" in str(e):
                print_error(f"Ошибка при отправке в {chat}: {e}")
                print_info(
                    f"Похоже, чат/канал '{chat}' неактивен, не существует, указан некорректно или вы не состоите в нём.\n"
                    f"Проверьте, что ссылка на чат/канал написана правильно (например, https://t.me/proverka_mls), "
                    f"и что бот/аккаунт добавлен в этот чат или канал."
                )
            else:
                print_error(f"Ошибка при отправке в {chat}: {e}")
        delay = random.randint(7, 15)
        print_wait(f"Ожидание {delay} сек перед следующим чатом...")
        await asyncio.sleep(delay)

async def send_single_message(client, chat, message, photo_path=None):
    try:
        print_action(f"Отправка сообщения в {chat} ...")
        if photo_path:
            await client.send_file(chat, photo_path, caption=message)
        else:
            await client.send_message(chat, message)
        print_success(f"Успешно отправлено в {chat}")
    except errors.ChatWriteForbiddenError:
        print_error(f"Нет прав писать в {chat} — возможно, вы не участник/подписчик. 🚫")
        print_info(f"Подключитесь к чату или каналу: {chat}, затем запустите скрипт снова.")
    except errors.UserPrivacyRestrictedError:
        print_error(f"Вы не можете писать в {chat} из-за настроек приватности.")
    except errors.UserNotParticipantError:
        print_error(f"Вы не участник чата/канала {chat}. Добавьте аккаунт в чат/канал!")
    except Exception as e:
        if "Cannot find any entity" in str(e):
            print_error(f"Ошибка при отправке в {chat}: {e}")
            print_info(
                f"Похоже, чат/канал '{chat}' неактивен, не существует, указан некорректно или вы не состоите в нём.\n"
                f"Проверьте, что ссылка или username указаны правильно (например, @proverka_mls), "
                f"и что бот/аккаунт добавлен в этот чат или канал."
            )
        else:
            print_error(f"Ошибка при отправке в {chat}: {e}")

def command_watcher(loop, custom_message_queue, next_cycle_time_holder):
    while True:
        cmd = input("Доступные команды: test @username_или_группа [-p], next - проверить время до следующего сообщения\n> ").strip()
        if cmd.lower().startswith("test "):
            parts = cmd.split(" ", 2)
            # Новый синтаксис: test @user [-p]
            if len(parts) >= 2 and parts[1].startswith("@"):
                chat = parts[1]
                message = None
                photo_needed = False
                if len(parts) >= 3 and parts[2].strip() == "-p":
                    photo_needed = True
                loop.call_soon_threadsafe(custom_message_queue.put_nowait, (chat, message, photo_needed))
            else:
                print_error("Формат: test @username_или_группа [-p]")
        elif cmd.lower() == "next":
            next_time = next_cycle_time_holder[0]
            if next_time:
                seconds_left = int(next_time - time.time())
                if seconds_left > 0:
                    print_info(f"До следующей плановой рассылки осталось {seconds_left} сек.")
                else:
                    print_info("Плановая рассылка начнётся с секунды на секунду!")
            else:
                print_info("Информация о следующем цикле пока недоступна.")
        elif cmd.lower() == "time":
            next_time = next_cycle_time_holder[0]
            if next_time:
                seconds_left = int(next_time - time.time())
                if seconds_left > 0:
                    print_info(f"Секунд до следующего цикла: {seconds_left}")
                else:
                    print_info("Следующий цикл начнётся с секунды на секунду!")
            else:
                print_info("Информация о следующем цикле пока недоступна.")
        elif cmd.lower() == "test":
            print_info("Формат: test @username_или_группа [-p], next - проверить время до следующего сообщения")

async def schedule_sender(client, chat_links, message_text, interval_seconds, custom_message_queue, photo_path, next_cycle_time_holder):
    print_info("Первая рассылка началась.")
    asyncio.create_task(send_messages(client, chat_links, message_text, photo_path))
    while True:
        next_cycle_time_holder[0] = time.time() + interval_seconds
        print_wait(f"Жду {interval_seconds} сек до следующей рассылки... ⏳ (или введите 'next' или 'time')")
        try:
            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(asyncio.sleep(interval_seconds)),
                    asyncio.create_task(custom_message_queue.get())
                ],
                return_when=asyncio.FIRST_COMPLETED
            )
            for completed in done:
                result = completed.result()
                if isinstance(result, tuple) and len(result) in (2, 3):
                    chat = result[0]
                    message = result[1] if result[1] is not None else message_text
                    photo_needed = result[2] if len(result) == 3 else False
                    photo_to_send = photo_path if photo_needed else None
                    print_info(f"Ручная команда: отправка сообщения в {chat}" + (" с фото" if photo_to_send else ""))
                    asyncio.create_task(send_single_message(client, chat, message, photo_to_send))
                else:
                    print_info("Плановая рассылка началась.")
                    asyncio.create_task(send_messages(client, chat_links, message_text, photo_path))
        except Exception as e:
            print_error(f"Ошибка планировщика: {e}")

async def main():
    print_header()
    ensure_photos_folder()
    settings = get_settings()
    api_id = int(settings['api_id'])
    api_hash = settings['api_hash']
    phone_number = settings['phone_number']
    chat_links = [link.strip() for link in settings['chat_links'].split(',') if link.strip()]
    message_text = settings['message_text']
    interval_seconds = int(settings.get('interval_seconds', '1800'))
    loop = asyncio.get_running_loop()
    custom_message_queue = asyncio.Queue()
    next_cycle_time_holder = [0]

    photo_path = get_first_photo()
    if photo_path:
        print_info(f"Будет использоваться фото для рассылки: {photo_path}")
    else:
        print_info("Фото для рассылки не найдено. Сообщения будут без фото.")

    Thread(target=command_watcher, args=(loop, custom_message_queue, next_cycle_time_holder), daemon=True).start()

    async with TelegramClient("session_with_photo", api_id, api_hash) as client:
        await client.start(phone_number)
        print_success("Бот успешно авторизован и готов к рассылке!")
        await schedule_sender(client, chat_links, message_text, interval_seconds, custom_message_queue, photo_path, next_cycle_time_holder)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print_error("Скрипт остановлен пользователем.")
